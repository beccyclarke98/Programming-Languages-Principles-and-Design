
class TextFrequency:

    def __init__(self, file_name):

        self.text = []
        self.file_name = file_name

        self.getText()

    def getText(self):

        with open(self.file_name, 'r') as file:
            self.text = file.readlines()
            file.close()

    def letterFreq(self):

        freq = {}

        for line in self.text:
            for char in line:
                
                if char in freq:
                    freq[char] += 1
                else:
                    freq[char] = 1

        return freq

    def wordFreq(self):

        freq = {}

        for line in self.text:
            for word in line.split():

                if word in freq:
                    freq[word] += 1
                else:
                    freq[word] = 1

        return freq

    def toLower(self):

        for e, line in enumerate(self.text):
            self.text[e] = line.lower()


class HistogramPrinter(TextFrequency):

    def __init__(self, file_name):

        TextFrequency.__init__(self, file_name)

    def printLetterHist(self):

        freq = self.letterFreq()

        for letter, freq in freq.items():
            print(letter, '*' * freq)

    def printWordHist(self):
        
        freq = self.wordFreq()
        
        for word, freq in freq.items():
            print(word, '*' * freq)





myTextFrequency = TextFrequency('lyrics.txt')
wordFreq = myTextFrequency.wordFreq()
letterFreq = myTextFrequency.letterFreq()

for letter, freq in letterFreq.items():
    print(letter, freq)
for word, freq in wordFreq.items():
    print(word, freq)


myHistogram = HistogramPrinter('lyrics.txt')
myHistogram.printLetterHist()

myHistogram = HistogramPrinter('lyrics.txt')
myHistogram.printWordHist()

myHistogram.toLower()
myHistogram.printLetterHist()
myHistogram.printWordHist()