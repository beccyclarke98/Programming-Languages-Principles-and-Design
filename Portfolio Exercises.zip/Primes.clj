(comment  Task 1 -  Get Divisors of a Number)

(defn get-divisors [n]
  (str (range 2 (inc (Math/floor (Math/sqrt n)))))
)

(println (get-divisors 4))
(println (get-divisors 101))

(println "----------------------")

(comment  Task 2 -  Number Divides?)

(defn divides? [x n]
  (zero? (mod n x) )
) 

(println (divides? 2 10))
(println (divides? 4 10))

(println "----------------------")

(comment Task 3 - Has No Divisors?)

(defn no-divisors? [n] 
  (->> (range 2 n) (filter #(divides? % n)) empty?)
)

(println (no-divisors? 9))
(println (no-divisors? 7))

(println "----------------------")

(comment Task 4 - Is Number Prime?)

(defn is-prime? [n] 
  (cond
    (<= n 1) false
    (= n 2) true
    :else (every? #(pos? (mod n %)) (range 2 (inc (Math/sqrt n)))))
)

(println (is-prime? 1))
(println (is-prime? 2))
(println (is-prime? 3))
(println (is-prime? 4))
(println (is-prime? 101))

(println "----------------------")

(comment  Task 5 - Prime Number Sequence in Range)

(defn is-prime [n]
  (empty? (filter #(= 0 (mod n %)) (range 2 n)))
)

(defn prime-seq [from to]
  (filter is-prime (range from (inc to)))
)

(println (prime-seq 50 100))
(println (prime-seq 7 11))

(println "----------------------")

(comment  Task 6 - Top 10 Primes In Range)

(defn print-top-primes[from to]
  (doseq [i (reverse (prime-seq from to))]
  (println i))
  (printf "Total = %d\n" (reduce + (prime-seq from to)))
)

(println (print-top-primes 50 100))
(println (print-top-primes 7 11)) 