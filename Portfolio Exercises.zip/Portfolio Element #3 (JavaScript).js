class ArithmeticTaskRunner 
{   
    //CONSTRUCTOR FOR TASKS 
    constructor() 
    {
        this.tasks = [];
    }

    get taskCount()
    {  
        return this.tasks.length;
    }

    addNegationTask()
    {
      this.tasks.push(x=> x * -1);
    }
    
    addAdditionTask(y) 
    {
       this.tasks.push(x => x + y);
    }
    
    addMultiplicationTask(y)
    {
        this.tasks.push(x => x * y);
    }

    execute(startValue = 0)
    {
        return this.tasks.reduce((y,x) => x(y), startValue);
    }
        
}

    print = console.log

    taskRunner = new ArithmeticTaskRunner()
    taskRunner.addAdditionTask(2)
    taskRunner.taskCount = 5;
    print(taskRunner.taskCount)
