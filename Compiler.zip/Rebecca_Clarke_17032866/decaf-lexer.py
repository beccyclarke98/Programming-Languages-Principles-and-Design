import os #Imports Operating System
import antlr4 as ant #Imports Antlr 4

os.system("java -Xmx500M -cp antlr-4.7.2-complete.jar org.antlr.v4.Tool -Dlanguage=Python3 Decaf.g4 -visitor") #Compiles When Run

from DecafLexer import DecafLexer #Imports Decaf Lexer File

filein = open('testdata/lexer/id1', 'r') #Reads In Specific File
lexer = DecafLexer(ant.InputStream(filein.read())) #Sets Lexer to Read In File

done = False #Done = False Until Done

token = lexer.nextToken() #Itterate Over Token (Used As An Inital Token Reader)

while (token.type != -1): #While Token Is Less than -1 (Always)
    print(lexer.symbolicNames[token.type]) #Prints Token Names
    token = lexer.nextToken() #Itterate To The Next Token
