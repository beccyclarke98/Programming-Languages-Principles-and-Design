import os #Imports Operating System
import antlr4 as ant #Imports Antlr 4

os.system("java -Xmx500M -cp antlr-4.7.2-complete.jar org.antlr.v4.Tool -Dlanguage=Python3 Decaf.g4 -visitor") #Compiles When Run

from DecafLexer import DecafLexer     #Imports Decaf Lexer File
from DecafParser import DecafParser   #Imports Decaf Parser File
from DecafVisitor import DecafVisitor #Imports Decaf Visitor File

class DecafTreeVisitor(DecafVisitor):
    def __init__(self):
        super().__init__()
        self.text = ''

    #Print Tree
    def printNode(self, ctx):
        self.text = self.text + '{\"name\": \"' + parser.ruleNames[ctx.getRuleIndex()] + '\",' + '\"value\":2,' + '\"children\":['
        self.visitChildren(ctx)
        self.text = self.text + ']},'
    
    #Removes Escaped Symbols from Char 
    def visitTerminal(self, ctx):
        self.text = self.text + '{\"name\": \"' + ctx.getText().replace('\\', '\\\\').replace('\"', '\\\"') + '\"},'

    #Vist Each Parser Rule
    def visitArith_op(self, ctx:DecafParser.Arith_opContext):
        self.printNode(ctx)

    def visitAssign_op(self, ctx:DecafParser.Assign_opContext):
        self.printNode(ctx)  

    def visitBin_op(self, ctx:DecafParser.Bin_opContext):
        self.printNode(ctx)

    def visitBlock(self, ctx:DecafParser.BlockContext):
        self.printNode(ctx)

    def visitCallout_arg(self, ctx:DecafParser.Callout_argContext):
        self.printNode(ctx)
    
    def visitCond_op(self, ctx:DecafParser.Cond_opContext):
        self.printNode(ctx)

    def visitData_type(self, ctx:DecafParser.Data_typeContext):
        self.printNode(ctx)

    def visitEq_op(self, ctx:DecafParser.Eq_opContext):
        self.printNode(ctx)

    def visitExpr(self, ctx:DecafParser.ExprContext):
        self.printNode(ctx)

    def visitField_decl(self, ctx:DecafParser.Field_declContext):
        self.printNode(ctx)

    def visitField_name(self, ctx:DecafParser.Field_nameContext):
        self.printNode(ctx)

    def visitLiteral(self, ctx:DecafParser.LiteralContext):
        self.printNode(ctx)

    def visitLocation(self, ctx:DecafParser.LocationContext):
        self.printNode(ctx)

    def visitMethod_call(self, ctx:DecafParser.Method_callContext):
        self.printNode(ctx)

    def visitMethod_decl(self, ctx:DecafParser.Method_declContext):
        self.printNode(ctx)

    def visitMethod_datatype(self, ctx:DecafParser.Method_datatypeContext):
       self.printNode(ctx)

    def visitMethod_name(self, ctx:DecafParser.Method_nameContext):
        self.printNode(ctx)

    def visitProgram(self, ctx:DecafParser.ProgramContext):
        self.printNode(ctx)

    def visitRel_op(self, ctx:DecafParser.Rel_opContext):
        self.printNode(ctx)

    def visitStatement(self, ctx:DecafParser.StatementContext):
        self.printNode(ctx)

    def visitVar_decl(self, ctx:DecafParser.Var_declContext):
        self.printNode(ctx)
    

source = 'testdata/semantics/illegal-01.dcf'
filein = open(source, 'r')
lexer = DecafLexer(ant.InputStream(filein.read()))

#create a token stream from the lexer
stream = ant.CommonTokenStream(lexer)

#create a new parser with the token stream as input
parser = DecafParser(stream)
tree = parser.program()

#create a new calc visitor
tree_visitor = DecafTreeVisitor()
tree_visitor.visit(tree)

#output code
print(tree_visitor.text)