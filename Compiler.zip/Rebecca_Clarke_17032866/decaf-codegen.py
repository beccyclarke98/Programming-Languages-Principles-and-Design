import os #Import Operating System
import antlr4 as ant #Import Antlr4
from SymbolTable import SymbolTable, VarSymbol, MethodSymbol #Import Methods From Symbol Table

os.system("java -Xmx500M -cp antlr-4.7.2-complete.jar org.antlr.v4.Tool -Dlanguage=Python3 Decaf.g4 -visitor") #Compiles Program On Run

from DecafLexer import DecafLexer #Import Decaf Lexer
from DecafParser import DecafParser #Import Decaf Parser
from DecafVisitor import DecafVisitor #Import Decaf Visitor

class DecafCodeGenVisitor(DecafVisitor):
    def __init__(self):
        super().__init__()

        #Only Two Scopes In Decaf Language Global + Method Scope
        self.GlobalScope = SymbolTable()
        self.MethodScope = SymbolTable()

    def visitProgram(self, ctx:DecafParser.ProgramContext):
        self.GlobalScope.enterScope() #Enter Global Scope
        print("Entered Global Scope") #Print Enter Global Scope

        #Loop Through Every Method Dec To See If "Main" Has Been Declared
        for x in range(len(ctx.method_decl())):
            MainFound = ctx.method_decl(x).ID(0).getText() #Set Main Found To The First ID Found Within The Loop Of Method Declarations
            print("Method Declaration Name: " , MainFound) #Prints The Method Declaration Name
            if MainFound == 'main': #If Main Found ID Is Main
                print("Main Found") #Print Main Found
            elif MainFound != 'main': #If Main Not Found
                print ("ERROR: Main Not Found Within Program!") #Print Error Main Not Found Message
                exit() #Exit The Program

        VisitChildren = self.visitChildren(ctx) #Visit Other Children Nodes

        self.GlobalScope.exitScope() #Exit Global Scope
        print("Exit Global Scope") #Print Exit Global Scope

        return VisitChildren

    def visitField_decl(self, ctx:DecafParser.Field_declContext):
        print("In Field Declaration")#Debugging Message To Say In Location

        line_number = ctx.start.line #Get Start Line

        paramatars_Type = ctx.data_type().getText() #Get The Paramater Data Type
        paramatars_Name = ctx.field_name(0).ID().getText() #Get The Paramater Name

        print("Paramater Type:" , paramatars_Type) #Prints Paramater Type
        print("Paramater Name:" , paramatars_Name) #Prints Paramater Name

        #Checking Array Size
        for x in range(len(ctx.field_name())):
            ContentsOfArray = ctx.field_name(x).INT_LITERAL() #Loop Over All Field Names + Get Contents Of Array
            print("Contents Within Array:" ,"[", ContentsOfArray, "]")  #Print Out The Contents Of The Array
            if ContentsOfArray != None: #Length Of Array Is Not Empty (Eg Has 1 Character Within It)
               ContentsOfArray = ContentsOfArray.getText() #Get The Number Within The Array
            if ContentsOfArray == '0': #If The Number Within The Array Is 0
                print("Array Cannot Be Size 0!")
                exit()
            else:
                print("Adding Symbol To Table") #Otherwise Add Array To Symbol Table
                var_symbol = VarSymbol( #Make A Var Symbol
                id = paramatars_Name,
                type = paramatars_Type,
                line = line_number,
                size = 1,
                mem = -1
            )
            self.GlobalScope.addSymbol(var_symbol) #Add Var Symbol To Gloabl Symbol Table

        VisitChildren = self.visitChildren(ctx) #Visit Other Children Nodes
        return VisitChildren

    def visitMethod_decl(self, ctx:DecafParser.Method_declContext):
        self.MethodScope.enterScope() #Entering Method Scope
        print("Entered Method Scope") #Print Entering Method Scope

        DataType = ctx.method_datatype().getText() #In Context Of method_datatype Get The Text
        print("Data Type:" , DataType) #Print Data Type

        MethodName = ctx.ID(0).getText() #Gets the 1st ID within Context Text
        print("Method Name: " , MethodName) #Prints This Method Name Out

        LineNumber = ctx.start.line #Get Starting Line Number
        print("Starting At Line: " , LineNumber) #Prints The Starting Line Number Out

        #Makes A Method Symbol
        method_symbol = MethodSymbol(
                id=MethodName,
                type=DataType,
                line=LineNumber,
                params=[]
                )

        self.MethodScope.addSymbol(method_symbol) #Adds The Method Symbol To The Method Symbol Table
        print("Added Method Symbol To Method Scope Symbol Table") #Prints Message For Adding Symbol

        VisitChildren = self.visitChildren(ctx) #Visit Other Children Nodes

        self.MethodScope.exitScope() #Exit Method Scope
        print("Exited Method Scope") #Print Exit Method Scope

        return VisitChildren #Return The Result Of Other Children Nodes


    def visitStatement(self, ctx:DecafParser.StatementContext):
        print("In Statement")
        VisitChildren = self.visitChildren(ctx) #Visit Other Children Nodes
        return VisitChildren

    def visitExpr(self, ctx:DecafParser.ExprContext):
        print("In Expression")
        VisitChildren = self.visitChildren(ctx) #Visit Other Children Nodes
        return VisitChildren

source = 'testdata/semantics/illegal-03'
filein = open(source + '.dcf', 'r')
lexer = DecafLexer(ant.InputStream(filein.read()))

#create a token stream from the lexer
stream = ant.CommonTokenStream(lexer)

#create a new parser with the token stream as input
parser = DecafParser(stream)
tree = parser.program()

#create a new calc visitor
codegen_visitor = DecafCodeGenVisitor()
codegen_visitor.visit(tree)
